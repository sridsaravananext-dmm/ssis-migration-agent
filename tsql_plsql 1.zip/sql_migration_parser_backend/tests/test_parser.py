
import unittest

from app.sql_parser import (
    parse_sql_text,
    split_sql_source,
)


class TestSQLParser(unittest.TestCase):

    # ---------------------------------------------------------
    # 1. SQL splitting tests
    # ---------------------------------------------------------

    def test_tsql_go_separator(self):
        source = "SELECT 1;\nGO\nSELECT 2;"

        parts = split_sql_source(source, "tsql")

        self.assertEqual(len(parts), 2)

    def test_semicolon_inside_string(self):
        source = "SELECT 'a;b' AS value; SELECT 2;"

        parts = split_sql_source(source, "tsql")

        self.assertEqual(len(parts), 2)
        self.assertIn("'a;b'", parts[0]["raw_sql"])

    def test_oracle_procedure(self):
        source = """CREATE OR REPLACE PROCEDURE demo AS
BEGIN
    INSERT INTO target_table(id) VALUES (1);
    UPDATE target_table SET id = 2;
END;
/
SELECT * FROM dual;
"""

        parts = split_sql_source(source, "plsql")

        self.assertGreaterEqual(len(parts), 2)
        self.assertIn("UPDATE target_table", parts[0]["raw_sql"])

    # ---------------------------------------------------------
    # 2. Basic parser and IR tests
    # ---------------------------------------------------------

    def test_intermediate_representation(self):
        result = parse_sql_text(
            "SELECT customer_id FROM customers;",
            "tsql",
        )

        self.assertEqual(result["statement_count"], 1)
        self.assertEqual(result["dialect"], "tsql")
        self.assertIn("source_sha256", result)
        self.assertIn("statements", result)

    def test_invalid_dialect(self):
        with self.assertRaises(ValueError):
            parse_sql_text("SELECT 1", "invalid")

    # ---------------------------------------------------------
    # 3. UPDATE target and source metadata
    # ---------------------------------------------------------

    def test_update_target_and_source_tables(self):
        source = """
        UPDATE target
        SET target.CustomerName = source.CustomerName
        FROM dbo.DimCustomer AS target
        INNER JOIN #CustomerStage AS source
            ON target.CustomerID = source.CustomerID;
        """

        result = parse_sql_text(source, "tsql")
        statement = result["statements"][0]

        self.assertEqual(statement["statement_type"], "UPDATE")

        self.assertIn(
            "dbo.DimCustomer",
            statement["target_tables"],
        )

        self.assertIn(
            "#CustomerStage",
            statement["source_tables"],
        )

        self.assertEqual(
            statement["aliases"].get("target"),
            "dbo.DimCustomer",
        )

        self.assertEqual(
            statement["aliases"].get("source"),
            "#CustomerStage",
        )

    # ---------------------------------------------------------
    # 4. CTE metadata
    # ---------------------------------------------------------

    def test_cte_is_not_a_physical_source_table(self):
        source = """
        WITH LatestCustomer AS (
            SELECT CustomerID
            FROM dbo.SourceCustomer
        )
        INSERT INTO #CustomerStage (CustomerID)
        SELECT CustomerID
        FROM LatestCustomer;
        """

        result = parse_sql_text(source, "tsql")
        statement = result["statements"][0]

        self.assertIn(
            "#CustomerStage",
            statement["target_tables"],
        )

        self.assertIn(
            "dbo.SourceCustomer",
            statement["source_tables"],
        )

        self.assertNotIn(
            "LatestCustomer",
            statement["source_tables"],
        )

    # ---------------------------------------------------------
    # 5. DROP TABLE inside conditional logic
    # ---------------------------------------------------------

    def test_drop_table_is_not_a_source(self):
        source = """
        IF OBJECT_ID('tempdb..#CustomerStage') IS NOT NULL
            DROP TABLE #CustomerStage;
        """

        result = parse_sql_text(source, "tsql")
        statement = result["statements"][0]

        self.assertNotIn(
            "#CustomerStage",
            statement["source_tables"],
        )

    # ---------------------------------------------------------
    # 6. Variable assignments
    # ---------------------------------------------------------

    def test_set_variable_assignment(self):
        source = "SET @RowsUpdated = @@ROWCOUNT;"

        result = parse_sql_text(source, "tsql")
        statement = result["statements"][0]

        self.assertEqual(
            statement["statement_type"],
            "VARIABLE_ASSIGNMENT",
        )

        self.assertEqual(
            statement["assignment"]["variable"],
            "@RowsUpdated",
        )

        self.assertEqual(
            statement["assignment"]["expression"],
            "@@ROWCOUNT",
        )

    def test_select_variable_assignment(self):
        source = """
        SELECT @RowsInserted = COUNT(*)
        FROM #CustomerStage;
        """

        result = parse_sql_text(source, "tsql")
        statement = result["statements"][0]

        self.assertTrue(
            statement.get("assignment")
            or statement["statement_type"] == "VARIABLE_ASSIGNMENT",
            "SELECT variable assignment was not recognized.",
        )

        self.assertIn(
            "#CustomerStage",
            statement["tables"],
        )

    # ---------------------------------------------------------
    # 7. Stored procedure detection
    # ---------------------------------------------------------

    def test_stored_procedure_detection(self):
        source = """
        EXEC dbo.usp_RebuildCustomerSummary
            @BatchID = @BatchID,
            @LoadDate = @LoadDate;
        """

        result = parse_sql_text(source, "tsql")
        statement = result["statements"][0]

        self.assertEqual(
            statement["statement_type"],
            "PROCEDURE_CALL",
        )

        self.assertIn(
            "dbo.usp_RebuildCustomerSummary",
            statement["procedures"],
        )

    # ---------------------------------------------------------
    # 8. Dynamic SQL analysis
    # ---------------------------------------------------------

    def test_dynamic_sql_is_preserved_and_parsed(self):
        source = """
        DECLARE @DynamicSQL NVARCHAR(MAX);

        SET @DynamicSQL =
            N'SELECT CustomerID
              FROM dbo.DimCustomer
              WHERE SourceSystem = @System;';
        """

        result = parse_sql_text(source, "tsql")

        self.assertEqual(result["statement_count"], 2)

        statement = result["statements"][1]

        self.assertEqual(
            statement["statement_type"],
            "DYNAMIC_SQL_ASSIGNMENT",
        )

        dynamic_sql = statement["dynamic_sql"]

        self.assertTrue(dynamic_sql["parsed"])

        self.assertIn(
            "dbo.DimCustomer",
            dynamic_sql["tables"],
        )

        self.assertIn(
            "CustomerID",
            dynamic_sql["columns"],
        )

    def test_dynamic_sql_is_not_executed(self):
        source = """
        DECLARE @DynamicSQL NVARCHAR(MAX);
        SET @DynamicSQL =
            N'SELECT CustomerID FROM dbo.DimCustomer;';
        """

        result = parse_sql_text(source, "tsql")

        self.assertEqual(result["statement_count"], 2)

        self.assertEqual(
            result["statements"][1]["statement_type"],
            "DYNAMIC_SQL_ASSIGNMENT",
        )

        # Parsing the string must not execute its SQL.
        self.assertTrue(result["statements"][1]["dynamic_sql"]["parsed"])

    # ---------------------------------------------------------
    # 9. DELETE target metadata
    # ---------------------------------------------------------

    def test_delete_target_table(self):
        source = """
        DELETE FROM dbo.CustomerStageArchive
        WHERE ArchiveDate < DATEADD(DAY, -90, @LoadDate);
        """

        result = parse_sql_text(source, "tsql")
        statement = result["statements"][0]

        self.assertEqual(statement["statement_type"], "DELETE")

        self.assertIn(
            "dbo.CustomerStageArchive",
            statement["target_tables"],
        )

        self.assertNotIn(
            "dbo.CustomerStageArchive",
            statement["source_tables"],
        )

    # ---------------------------------------------------------
    # 10. MERGE target and source metadata
    # ---------------------------------------------------------

    def test_merge_target_and_source_tables(self):
        source = """
        MERGE dbo.DimState AS target
        USING dbo.SourceState AS source
            ON target.StateCode = source.StateCode
        WHEN MATCHED THEN
            UPDATE SET target.StateName = source.StateName
        WHEN NOT MATCHED BY TARGET THEN
            INSERT (StateCode, StateName)
            VALUES (source.StateCode, source.StateName);
        """

        result = parse_sql_text(source, "tsql")
        statement = result["statements"][0]

        self.assertEqual(statement["statement_type"], "MERGE")

        self.assertIn(
            "dbo.DimState",
            statement["target_tables"],
        )

        self.assertIn(
            "dbo.SourceState",
            statement["source_tables"],
        )

    # ---------------------------------------------------------
    # 11. Result consistency
    # ---------------------------------------------------------

    def test_result_counts_are_consistent(self):
        source = """
        SELECT 1;
        SELECT 2;
        INSERT INTO dbo.TestTable (id) VALUES (1);
        """

        result = parse_sql_text(source, "tsql")

        self.assertEqual(
            result["statement_count"],
            len(result["statements"]),
        )

        self.assertEqual(
            result["parsed_count"] + result["failed_count"],
            result["statement_count"],
        )

    def test_oracle_select(self):
        source = "SELECT SYSDATE FROM dual;"

        result = parse_sql_text(source, "plsql")

        self.assertEqual(result["dialect"], "plsql")
        self.assertEqual(result["statement_count"], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)

