
import unittest

from app.ir import create_ir, create_statement_ir
from app.ir_validation import validate_ir


class TestIRValidation(unittest.TestCase):

    def create_valid_ir(self):
        source = "SELECT CustomerID FROM dbo.DimCustomer;"

        statement = create_statement_ir(
            statement_id=1,
            raw_sql=source,
            dialect="tsql",
            start_line=1,
            end_line=1,
            statement_type="SELECT",
            parsed=True,
            tables=["dbo.DimCustomer"],
            source_tables=["dbo.DimCustomer"],
            columns=["CustomerID"],
        )

        return create_ir(
            source_text=source,
            source_file="test.sql",
            dialect="tsql",
            statements=[statement],
        )

    def test_valid_ir(self):
        result = validate_ir(self.create_valid_ir())
        self.assertTrue(result["valid"], result["errors"])

    def test_missing_required_field(self):
        ir = self.create_valid_ir()
        del ir["source_file"]

        result = validate_ir(ir)

        self.assertFalse(result["valid"])
        self.assertTrue(
            any("source_file" in error for error in result["errors"])
        )

    def test_invalid_dialect(self):
        ir = self.create_valid_ir()
        ir["dialect"] = "invalid"

        result = validate_ir(ir)

        self.assertFalse(result["valid"])

    def test_inconsistent_statement_count(self):
        ir = self.create_valid_ir()
        ir["statement_count"] = 2

        result = validate_ir(ir)

        self.assertFalse(result["valid"])


if __name__ == "__main__":
    unittest.main()
