from __future__ import annotations
from app.ir import create_ir, create_statement_ir
import hashlib
import re
from pathlib import Path
from typing import Any
import sqlglot
from sqlglot import exp

SUPPORTED_DIALECTS = {"tsql", "plsql"}
SCHEMA_VERSION = "1.2"
IDENTIFIER = r'(?:\[[^\]]+\]|"(?:[^"]|"")+"|`[^`]+`|[#@A-Za-z_][\w$#@]*)'
QUALIFIED_IDENTIFIER = IDENTIFIER + r'(?:\s*\.\s*' + IDENTIFIER + r')*'

def normalize_dialect(dialect: str) -> str:
    if not isinstance(dialect, str) or dialect.strip().lower() not in SUPPORTED_DIALECTS:
        raise ValueError("Unsupported dialect. Choose 'tsql' or 'plsql'.")
    return dialect.strip().lower()

def sqlglot_dialect(dialect: str) -> str:
    return "tsql" if normalize_dialect(dialect) == "tsql" else "oracle"

def clean_identifier(value: str) -> str:
    return re.sub(r"\s*\.\s*", ".", value.strip())

def unique(values: list[str]) -> list[str]:
    result, seen = [], set()
    for value in values:
        value = clean_identifier(value)
        if value and value.lower() not in seen:
            seen.add(value.lower()); result.append(value)
    return result

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def is_comment_only(sql: str) -> bool:
    sql = re.sub(r"/\*.*?\*/", "", sql, flags=re.S)
    sql = re.sub(r"--[^\n]*", "", sql)
    return not sql.strip()

def split_semicolon_statements(sql_text: str) -> list[dict[str, Any]]:
    out, buf = [], []
    line = start_line = 1
    i = 0
    single = double = backtick = bracket = line_comment = False
    block_depth = 0
    def save(end_line: int):
        nonlocal buf, start_line
        raw = "".join(buf).strip()
        if raw and not is_comment_only(raw):
            out.append({"raw_sql": raw, "start_line": start_line, "end_line": end_line})
        buf = []
        start_line = end_line + 1
    while i < len(sql_text):
        c = sql_text[i]; n = sql_text[i+1] if i+1 < len(sql_text) else ""
        if line_comment:
            buf.append(c)
            if c == "\n": line_comment = False; line += 1
            i += 1; continue
        if block_depth:
            buf.append(c)
            if c == "/" and n == "*": buf.append(n); block_depth += 1; i += 2; continue
            if c == "*" and n == "/": buf.append(n); block_depth -= 1; i += 2; continue
            if c == "\n": line += 1
            i += 1; continue
        if single:
            buf.append(c)
            if c == "'" and n == "'": buf.append(n); i += 2; continue
            if c == "'": single = False
            if c == "\n": line += 1
            i += 1; continue
        if double:
            buf.append(c)
            if c == '"' and n == '"': buf.append(n); i += 2; continue
            if c == '"': double = False
            if c == "\n": line += 1
            i += 1; continue
        if backtick:
            buf.append(c)
            if c == "`": backtick = False
            if c == "\n": line += 1
            i += 1; continue
        if bracket:
            buf.append(c)
            if c == "]" and n == "]": buf.append(n); i += 2; continue
            if c == "]": bracket = False
            if c == "\n": line += 1
            i += 1; continue
        if c == "-" and n == "-": buf.extend([c,n]); line_comment = True; i += 2; continue
        if c == "/" and n == "*": buf.extend([c,n]); block_depth = 1; i += 2; continue
        if c == "'": buf.append(c); single = True; i += 1; continue
        if c == '"': buf.append(c); double = True; i += 1; continue
        if c == "`": buf.append(c); backtick = True; i += 1; continue
        if c == "[": buf.append(c); bracket = True; i += 1; continue
        if c == ";": buf.append(c); save(line); i += 1; continue
        buf.append(c)
        if c == "\n": line += 1
        i += 1
    raw = "".join(buf).strip()
    if raw and not is_comment_only(raw): out.append({"raw_sql": raw, "start_line": start_line, "end_line": line})
    return out

def split_tsql_batches(sql_text: str) -> list[dict[str, Any]]:
    out, buf = [], []
    start = 1; line_no = 1
    for line in sql_text.splitlines(keepends=True):
        if re.match(r"^\s*GO\s*(?:--.*)?$", line, re.I):
            raw = "".join(buf).strip()
            if raw and not is_comment_only(raw): out.append({"raw_sql":raw,"start_line":start,"end_line":line_no})
            buf=[]; start=line_no+1
        else: buf.append(line)
        line_no += line.count("\n")
    raw="".join(buf).strip()
    if raw and not is_comment_only(raw): out.append({"raw_sql":raw,"start_line":start,"end_line":line_no})
    return out

def split_plsql_blocks(sql_text: str) -> list[dict[str, Any]]:
    out=[]; plain=[]; block=[]; in_block=False; line_no=1; start=1; plain_start=1
    starter=re.compile(r"^\s*(?:DECLARE\b|BEGIN\b|CREATE\s+(?:(?:OR\s+REPLACE)\s+)?(?:(?:EDITIONABLE|NONEDITIONABLE)\s+)?(?:PROCEDURE|FUNCTION|PACKAGE|TRIGGER|TYPE)\b)", re.I)
    def flush_plain(text, base):
        for item in split_semicolon_statements(text):
            item["start_line"] += base-1; item["end_line"] += base-1; out.append(item)
    for line in sql_text.splitlines(keepends=True):
        if not in_block and starter.match(line):
            if plain: flush_plain("".join(plain), plain_start)
            plain=[]; block=[]; start=line_no; in_block=True
        if in_block:
            if line.strip()=="/":
                raw="".join(block).strip()
                if raw: out.append({"raw_sql":raw,"start_line":start,"end_line":line_no-1})
                block=[]; in_block=False; plain_start=line_no+1
            else: block.append(line)
        else:
            if not plain: plain_start=line_no
            plain.append(line)
        line_no += line.count("\n")
    if in_block:
        raw="".join(block).strip()
        if raw: out.append({"raw_sql":raw,"start_line":start,"end_line":line_no})
    elif plain: flush_plain("".join(plain), plain_start)
    return out

def split_sql_source(sql_text: str, dialect: str = "tsql") -> list[dict[str, Any]]:
    dialect=normalize_dialect(dialect)
    if dialect=="plsql": return split_plsql_blocks(sql_text)
    out=[]
    for batch in split_tsql_batches(sql_text):
        for part in split_semicolon_statements(batch["raw_sql"]):
            part["start_line"] += batch["start_line"]-1
            part["end_line"] += batch["start_line"]-1
            out.append(part)
    return out

def effective_statement(sql: str) -> str:
    """Return main statement keyword context, including WITH CTE prefixes."""
    text=sql.lstrip()
    if not re.match(r"(?is)^WITH\b", text): return text
    # Find the first top-level DML keyword after the CTE definitions.
    depth=0; single=False; i=0
    while i < len(text):
        c=text[i]
        if single:
            if c=="'":
                if i+1<len(text) and text[i+1]=="'": i+=2; continue
                single=False
            i+=1; continue
        if c=="'": single=True; i+=1; continue
        if c=="(": depth+=1
        elif c==")": depth=max(0,depth-1)
        elif depth==0:
            m=re.match(r"(?is)(INSERT|SELECT|UPDATE|DELETE|MERGE)\b", text[i:])
            if m: return text[i:]
        i+=1
    return text

def classify_statement(sql: str) -> str:
    text = effective_statement(sql).strip()

    # Classify procedure invocations explicitly before any parser-derived type.
    if re.match(r"(?is)^EXEC(?:UTE)?\b", text):
        return "PROCEDURE_CALL"

    if re.search(r"(?is)\bSET\s+@[\w]+\s*=\s*(?:N\s*)?'", text): return "DYNAMIC_SQL_ASSIGNMENT"
    patterns=[
        (r"^CREATE\s+(?:OR\s+REPLACE\s+)?(?:(?:EDITIONABLE|NONEDITIONABLE)\s+)?PROCEDURE\b","CREATE_PROCEDURE"),
        (r"^CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\b","CREATE_FUNCTION"),
        (r"^CREATE\s+(?:OR\s+REPLACE\s+)?PACKAGE\b","CREATE_PACKAGE"),
        (r"^CREATE\s+(?:OR\s+REPLACE\s+)?TRIGGER\b","CREATE_TRIGGER"),
        (r"^CREATE\b","CREATE"),(r"^ALTER\b","ALTER"),(r"^DROP\b","DROP"),
        (r"^TRUNCATE\b","TRUNCATE"),(r"^MERGE\b","MERGE"),(r"^INSERT\b","INSERT"),
        (r"^UPDATE\b","UPDATE"),(r"^DELETE\b","DELETE"),
    ]
    for pattern, kind in patterns:
        if re.match(pattern,text,re.I): return kind
    if re.match(r"(?is)^SELECT\s+@[\w]+\s*=", text): return "VARIABLE_ASSIGNMENT"
    if re.match(r"(?is)^SELECT\b", text): return "SELECT"
    if re.match(r"(?is)^SET\s+@[\w]+\s*=", text): return "VARIABLE_ASSIGNMENT"
    if re.match(r"(?is)^EXEC(?:UTE)?\b", text): return "PROCEDURE_CALL"
    if re.match(r"(?is)^DECLARE\b", text): return "DECLARE"
    if re.match(r"(?is)^(?:BEGIN|END)\b", text): return "PLSQL_BLOCK"
    return "UNKNOWN"

def extract_cte_names(sql: str) -> set[str]:
    names=set()
    pattern=re.compile(rf"(?is)(?:\bWITH\b|,)\s*({IDENTIFIER})\s*(?:\([^)]*\)\s*)?AS\s*\(")
    for m in pattern.finditer(sql): names.add(clean_identifier(m.group(1)).lower())
    return names

def find_table_references(sql: str) -> list[str]:
    pattern=re.compile(rf"(?is)\b(?:FROM|JOIN|USING|INTO|REFERENCES|TABLE)\s+({QUALIFIED_IDENTIFIER})")
    found=[]
    for m in pattern.finditer(sql):
        name=clean_identifier(m.group(1))
        if name.upper() not in {"SELECT","SET","VALUES","WHERE","ON","AS","INTO","JOIN","UPDATE","DELETE"}: found.append(name)
    return unique(found)

def extract_target_tables(sql: str, statement_type: str) -> list[str]:
    sql=effective_statement(sql); kind=statement_type.upper()
    if kind=="UPDATE":
        m=re.search(rf"(?is)\bUPDATE\s+(?:TOP\s*\([^)]*\)\s*)?({QUALIFIED_IDENTIFIER})",sql)
        if not m: return []
        initial=clean_identifier(m.group(1))
        if "." not in initial:
            am=re.search(rf"(?is)\bFROM\s+({QUALIFIED_IDENTIFIER})\s+(?:AS\s+)?{re.escape(initial)}\b",sql)
            if am: return [clean_identifier(am.group(1))]
        return [initial]
    patterns={
        "INSERT":rf"(?is)\bINSERT\s+(?:INTO\s+)?({QUALIFIED_IDENTIFIER})",
        "DELETE":rf"(?is)\bDELETE\s+(?:FROM\s+)?({QUALIFIED_IDENTIFIER})",
        "MERGE":rf"(?is)\bMERGE\s+(?:INTO\s+)?({QUALIFIED_IDENTIFIER})",
        "TRUNCATE":rf"(?is)\bTRUNCATE\s+TABLE\s+({QUALIFIED_IDENTIFIER})",
        "DROP":rf"(?is)\bDROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?({QUALIFIED_IDENTIFIER})",
        "CREATE":rf"(?is)\bCREATE\s+TABLE\s+({QUALIFIED_IDENTIFIER})",
        "ALTER":rf"(?is)\bALTER\s+TABLE\s+({QUALIFIED_IDENTIFIER})",
    }
    pattern=patterns.get(kind)
    m=re.search(pattern,sql) if pattern else None
    return [clean_identifier(m.group(1))] if m else []

def extract_source_tables(sql: str, statement_type: str) -> list[str]:
    kind=statement_type.upper()
    if kind not in {"SELECT","VARIABLE_ASSIGNMENT","INSERT","UPDATE","DELETE","MERGE","CREATE_PROCEDURE","CREATE_FUNCTION","CREATE_PACKAGE","CREATE_TRIGGER","PROCEDURE_CALL"}:
        return []
    references=find_table_references(sql)
    ctes=extract_cte_names(sql)
    targets={x.lower() for x in extract_target_tables(sql,kind)}
    aliases=set()
    if kind=="UPDATE":
        m=re.search(rf"(?is)\bUPDATE\s+({IDENTIFIER})",effective_statement(sql))
        if m and "." not in m.group(1): aliases.add(m.group(1).lower())
    return unique([x for x in references if x.lower() not in ctes and x.lower() not in targets and x.lower() not in aliases])

def extract_columns(sql: str, dialect: str) -> list[str]:
    try: expressions=sqlglot.parse(sql,read=sqlglot_dialect(dialect))
    except Exception: return []
    cols=[]
    for expression in expressions:
        if expression is not None:
            for col in expression.find_all(exp.Column):
                try: cols.append(col.sql(dialect=sqlglot_dialect(dialect)))
                except Exception: pass
    return unique(cols)

def extract_aliases(sql: str) -> dict[str,str]:
    result={}
    pattern=re.compile(rf"(?is)\b(?:FROM|JOIN|USING)\s+({QUALIFIED_IDENTIFIER})\s+(?:AS\s+)?({IDENTIFIER})")
    reserved={"WHERE","JOIN","ON","SET","WHEN","USING","INNER","LEFT","RIGHT","FULL","CROSS","GROUP","ORDER","UNION"}
    for m in pattern.finditer(sql):
        alias=clean_identifier(m.group(2))
        if alias.upper() not in reserved: result[alias]=clean_identifier(m.group(1))
    return result

def extract_procedure_name(sql: str) -> str | None:
    m=re.search(rf"(?is)\bCREATE\s+(?:OR\s+REPLACE\s+)?(?:(?:EDITIONABLE|NONEDITIONABLE)\s+)?(?:PROCEDURE|PROC|FUNCTION|PACKAGE)\s+({QUALIFIED_IDENTIFIER})",sql)
    if m: return clean_identifier(m.group(1))
    m=re.match(rf"(?is)^\s*EXEC(?:UTE)?\s+({QUALIFIED_IDENTIFIER})",sql)
    return clean_identifier(m.group(1)) if m else None

def extract_assignment(sql: str) -> dict[str,str] | None:
    patterns=[r"(?is)\bSET\s+(@[\w]+)\s*=\s*(.*?);?\s*$",r"(?is)^\s*SELECT\s+(@[\w]+)\s*=\s*(.*?);?\s*$"]
    for pattern in patterns:
        m=re.search(pattern,sql.strip())
        if m: return {"variable":m.group(1),"expression":m.group(2).strip()}
    return None

def extract_dynamic_sql(sql: str) -> dict[str, Any] | None:
    # Capture the complete Unicode/non-Unicode SQL string literal, including
    # newlines and semicolons inside the literal. This only parses the text;
    # it never executes the dynamic SQL.
    pattern = re.compile(
        r"(?is)\bSET\s+(@[\w]+)\s*=\s*((?:N\s*)?'(?:''|[^'])*')"
    )
    match = pattern.search(sql)
    if not match:
        return None

    literal = re.sub(r"(?is)^N\s*", "", match.group(2)).strip()
    inner_sql = literal[1:-1].replace("''", "'").strip()

    try:
        expressions = sqlglot.parse(inner_sql, read="tsql")
        parsed = any(expression is not None for expression in expressions)
        error = None
    except Exception as exc:
        parsed = False
        error = str(exc)

    return {
        "variable": match.group(1),
        "sql": inner_sql,
        "parsed": parsed,
        "error": error,
        # Metadata is extracted from the SQL string only. Nothing is executed.
        "tables": find_table_references(inner_sql),
        "columns": extract_columns(inner_sql, "tsql"),
    }

def parse_one_statement(statement: dict[str,Any], dialect: str, statement_id: int=1) -> dict[str,Any]:
    dialect=normalize_dialect(dialect); sql=statement["raw_sql"].strip(); kind=classify_statement(sql)
    dynamic=extract_dynamic_sql(sql) if kind=="DYNAMIC_SQL_ASSIGNMENT" else None
    tables=find_table_references(sql)
    targets=extract_target_tables(sql,kind)
    sources=extract_source_tables(sql,kind)
    tables=unique(tables+targets)
    try:
        expressions=sqlglot.parse(sql,read=sqlglot_dialect(dialect))
        parsed=any(x is not None for x in expressions); parse_error=None
    except Exception as exc:
        parsed=False; parse_error=str(exc)
    diagnostics=[]
    if parse_error: diagnostics.append({"severity":"WARNING","message":parse_error})
    if dynamic and not dynamic["parsed"]: diagnostics.append({"severity":"WARNING","message":"Dynamic SQL could not be parsed."})
    procedure_name = extract_procedure_name(sql)

    return {
        "statement_id":statement_id,"statement_type":kind,"dialect":dialect,
        "start_line":statement.get("start_line",1),"end_line":statement.get("end_line",1),
        "parsed":parsed,"tables":tables,"columns":extract_columns(sql,dialect),
        "target_tables":unique(targets),"source_tables":unique(sources),
        "aliases":extract_aliases(sql),
        "procedure":{"name":procedure_name} if procedure_name else None,
        # Keep a simple list as well for consumers that need procedure names.
        "procedures":[procedure_name] if procedure_name else [],
        "assignment":extract_assignment(sql),"dynamic_sql":dynamic,
        "raw_sql":sql,"diagnostics":diagnostics,
    }

def parse_sql_text(sql_text: str, source_file: str="input.sql", dialect: str="tsql", include_raw_sql: bool=True) -> dict[str,Any]:
    # Backward-compatible forms:
    #   parse_sql_text(sql, "tsql")
    #   parse_sql_text(sql, "plsql")
    #   parse_sql_text(sql, dialect="tsql")
    # Any unsupported second positional value is treated as a dialect and
    # rejected, rather than silently accepted as a filename.
    if source_file != "input.sql" and dialect == "tsql":
        dialect = source_file
        source_file = "input.sql"

    dialect = normalize_dialect(dialect)
    if not isinstance(sql_text,str): raise TypeError("sql_text must be a string.")
    parts=split_sql_source(sql_text,dialect)
    statements=[parse_one_statement(part,dialect,i) for i,part in enumerate(parts,1)]
    parsed_count=sum(1 for s in statements if s["parsed"])
    failed_count=len(statements)-parsed_count
    return {"schema_version":SCHEMA_VERSION,"source_file":source_file,"source_sha256":sha256_text(sql_text),"dialect":dialect,"statement_count":len(statements),"parsed_count":parsed_count,"failed_count":failed_count,"status":"success" if failed_count==0 else "partial","statements":statements}

def parse_sql_file(file_path: str | Path, dialect: str="tsql", include_raw_sql: bool=True) -> dict[str,Any]:
    path=Path(file_path)
    if not path.exists(): raise FileNotFoundError(f"SQL file not found: {path}")
    if not path.is_file(): raise ValueError(f"Expected a file, got: {path}")
    return parse_sql_text(path.read_text(encoding="utf-8-sig"),source_file=path.name,dialect=dialect,include_raw_sql=include_raw_sql)











