
from __future__ import annotations

from typing import Any


SUPPORTED_DIALECTS = {"tsql", "plsql"}

REQUIRED_IR_FIELDS = {
    "schema_version",
    "source_file",
    "source_sha256",
    "dialect",
    "statement_count",
    "parsed_count",
    "failed_count",
    "status",
    "statements",
}

REQUIRED_STATEMENT_FIELDS = {
    "statement_id",
    "statement_type",
    "dialect",
    "start_line",
    "end_line",
    "parsed",
    "raw_sql",
    "tables",
    "source_tables",
    "target_tables",
    "columns",
    "aliases",
    "procedure",
    "assignment",
    "dynamic_sql",
    "diagnostics",
}


def validate_ir(ir: dict[str, Any]) -> dict[str, Any]:
    """
    Validate the structure and consistency of a generated SQL IR.

    Returns:
        {
            "valid": bool,
            "errors": list[str],
            "warnings": list[str]
        }
    """

    errors: list[str] = []
    warnings: list[str] = []

    # --------------------------------------------------------
    # 1. Validate the top-level object
    # --------------------------------------------------------

    if not isinstance(ir, dict):
        return {
            "valid": False,
            "errors": ["IR must be a JSON object / Python dictionary."],
            "warnings": [],
        }

    missing_fields = REQUIRED_IR_FIELDS - set(ir.keys())

    for field in sorted(missing_fields):
        errors.append(f"Missing required IR field: {field}")

    if missing_fields:
        return {
            "valid": False,
            "errors": errors,
            "warnings": warnings,
        }

    # --------------------------------------------------------
    # 2. Validate dialect and basic metadata
    # --------------------------------------------------------

    if ir["dialect"] not in SUPPORTED_DIALECTS:
        errors.append(
            f"Unsupported dialect: {ir['dialect']!r}. "
            "Expected 'tsql' or 'plsql'."
        )

    if not isinstance(ir["schema_version"], str):
        errors.append("schema_version must be a string.")

    if not isinstance(ir["source_file"], str) or not ir["source_file"].strip():
        errors.append("source_file must be a non-empty string.")

    source_hash = ir["source_sha256"]

    if (
        not isinstance(source_hash, str)
        or len(source_hash) != 64
        or any(char not in "0123456789abcdefABCDEF" for char in source_hash)
    ):
        errors.append("source_sha256 must be a 64-character hexadecimal hash.")

    # --------------------------------------------------------
    # 3. Validate statement collection and counts
    # --------------------------------------------------------

    statements = ir["statements"]

    if not isinstance(statements, list):
        errors.append("statements must be a list.")

        return {
            "valid": False,
            "errors": errors,
            "warnings": warnings,
        }

    statement_count = ir["statement_count"]
    parsed_count = ir["parsed_count"]
    failed_count = ir["failed_count"]

    for field, value in (
        ("statement_count", statement_count),
        ("parsed_count", parsed_count),
        ("failed_count", failed_count),
    ):
        # bool is a subclass of int, so explicitly reject it.
        if isinstance(value, bool) or not isinstance(value, int):
            errors.append(f"{field} must be an integer.")
        elif value < 0:
            errors.append(f"{field} cannot be negative.")

    if all(
        isinstance(value, int) and not isinstance(value, bool)
        and value >= 0
        for value in (statement_count, parsed_count, failed_count)
    ):
        if statement_count != len(statements):
            errors.append(
                "statement_count does not match the number of statements."
            )

        if parsed_count + failed_count != statement_count:
            errors.append(
                "parsed_count + failed_count must equal statement_count."
            )

    # --------------------------------------------------------
    # 4. Validate each statement
    # --------------------------------------------------------

    actual_parsed_count = 0
    actual_failed_count = 0
    seen_ids: set[int] = set()

    for index, statement in enumerate(statements):
        prefix = f"statements[{index}]"

        if not isinstance(statement, dict):
            errors.append(f"{prefix} must be an object.")
            continue

        missing_statement_fields = (
            REQUIRED_STATEMENT_FIELDS - set(statement.keys())
        )

        for field in sorted(missing_statement_fields):
            errors.append(f"{prefix} is missing required field: {field}")

        if missing_statement_fields:
            continue

        statement_id = statement["statement_id"]

        if (
            isinstance(statement_id, bool)
            or not isinstance(statement_id, int)
            or statement_id < 1
        ):
            errors.append(f"{prefix}.statement_id must be a positive integer.")
        elif statement_id in seen_ids:
            errors.append(f"Duplicate statement_id: {statement_id}")
        else:
            seen_ids.add(statement_id)

        if statement["dialect"] != ir["dialect"]:
            errors.append(
                f"{prefix}.dialect does not match the document dialect."
            )

        if not isinstance(statement["statement_type"], str):
            errors.append(f"{prefix}.statement_type must be a string.")

        if not isinstance(statement["parsed"], bool):
            errors.append(f"{prefix}.parsed must be a boolean.")
        elif statement["parsed"]:
            actual_parsed_count += 1
        else:
            actual_failed_count += 1

        if not isinstance(statement["raw_sql"], str):
            errors.append(f"{prefix}.raw_sql must be a string.")
        elif not statement["raw_sql"].strip():
            warnings.append(f"{prefix}.raw_sql is empty.")

        start_line = statement["start_line"]
        end_line = statement["end_line"]

        if (
            isinstance(start_line, bool)
            or not isinstance(start_line, int)
            or start_line < 1
        ):
            errors.append(f"{prefix}.start_line must be a positive integer.")

        if (
            isinstance(end_line, bool)
            or not isinstance(end_line, int)
            or end_line < 1
        ):
            errors.append(f"{prefix}.end_line must be a positive integer.")
        elif (
            isinstance(start_line, int)
            and not isinstance(start_line, bool)
            and start_line >= 1
            and end_line < start_line
        ):
            errors.append(f"{prefix}.end_line cannot precede start_line.")

        for field in ("tables", "source_tables", "target_tables", "columns", "diagnostics"):
            value = statement[field]

            if not isinstance(value, list):
                errors.append(f"{prefix}.{field} must be a list.")
            elif not all(isinstance(item, str) for item in value):
                errors.append(
                    f"Every item in {prefix}.{field} must be a string."
                )

        if not isinstance(statement["aliases"], dict):
            errors.append(f"{prefix}.aliases must be an object.")

        for field in ("procedure", "assignment", "dynamic_sql"):
            value = statement[field]

            if value is not None and not isinstance(value, dict):
                errors.append(
                    f"{prefix}.{field} must be an object or null."
                )

    # --------------------------------------------------------
    # 5. Verify actual parsed/failed counts
    # --------------------------------------------------------

    if isinstance(parsed_count, int) and not isinstance(parsed_count, bool):
        if parsed_count != actual_parsed_count:
            errors.append(
                "parsed_count does not match statement-level parsed flags."
            )

    if isinstance(failed_count, int) and not isinstance(failed_count, bool):
        if failed_count != actual_failed_count:
            errors.append(
                "failed_count does not match statement-level parsed flags."
            )

    # --------------------------------------------------------
    # 6. Validate document status
    # --------------------------------------------------------

    status = ir["status"]

    if status not in {"success", "partial_success", "failed"}:
        errors.append(
            "status must be 'success', 'partial_success', or 'failed'."
        )
    elif (
        isinstance(parsed_count, int)
        and not isinstance(parsed_count, bool)
        and isinstance(failed_count, int)
        and not isinstance(failed_count, bool)
    ):
        expected_status = (
            "success"
            if failed_count == 0
            else "partial_success"
            if parsed_count > 0
            else "failed"
        )

        if status != expected_status:
            errors.append(
                f"status is {status!r}, but expected {expected_status!r}."
            )

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
    }

