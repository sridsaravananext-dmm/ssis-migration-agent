
from pathlib import Path
import hashlib
import logging

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.sql_parser import parse_sql_text
from app.ir import create_ir, create_statement_ir
from app.ir_validation import validate_ir


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sql-migration-parser")

app = FastAPI(
    title="SQL Migration Parser API",
    version="1.1.0",
    description=(
        "Parse T-SQL and Oracle PL/SQL, build an intermediate "
        "representation, and validate it without executing SQL."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

MAX_UPLOAD_BYTES = 10 * 1024 * 1024
ALLOWED_EXTENSIONS = {".sql", ".pls", ".pks", ".pkb"}
SUPPORTED_DIALECTS = {"tsql", "plsql"}


@app.get("/")
def health_check():
    return {
        "service": "SQL Migration Parser API",
        "status": "running",
        "supported_dialects": ["tsql", "plsql"],
        "executes_uploaded_sql": False,
        "ir_enabled": True,
        "ir_validation_enabled": True,
    }


def build_ir_from_parser_result(
    source: str,
    filename: str,
    dialect: str,
    parser_result: dict,
) -> dict:
    """Convert existing parser output into the standard IR."""

    statements = []

    for index, item in enumerate(
        parser_result.get("statements", []),
        start=1,
    ):
        statement = create_statement_ir(
            statement_id=item.get("statement_id", index),
            raw_sql=item.get("raw_sql", ""),
            dialect=dialect,
            start_line=item.get("start_line", 1),
            end_line=item.get(
                "end_line",
                item.get("start_line", 1),
            ),
            statement_type=item.get("statement_type", "UNKNOWN"),
            parsed=item.get("parsed", False),
            tables=item.get("tables", []),
            source_tables=item.get("source_tables", []),
            target_tables=item.get("target_tables", []),
            columns=item.get("columns", []),
            aliases=item.get("aliases", {}),
            procedure=item.get("procedure"),
            assignment=item.get("assignment"),
            dynamic_sql=item.get("dynamic_sql"),
            diagnostics=item.get("diagnostics", []),
        )

        statements.append(statement)

    return create_ir(
        source_text=source,
        source_file=filename,
        dialect=dialect,
        statements=statements,
    )


@app.post("/parse")
async def parse_uploaded_sql(
    file: UploadFile = File(...),
    dialect: str = Form(...),
    include_raw_sql: bool = Form(True),
):
    try:
        # 1. Validate the dialect.
        dialect = dialect.strip().lower()

        if dialect not in SUPPORTED_DIALECTS:
            raise HTTPException(
                status_code=400,
                detail="Select 'tsql' or 'plsql'.",
            )

        # 2. Validate the uploaded filename.
        filename = Path(file.filename or "uploaded.sql").name
        extension = Path(filename).suffix.lower()

        if extension not in ALLOWED_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Supported extensions: .sql, .pls, .pks, .pkb"
                ),
            )

        # 3. Read the file with a size limit.
        content = await file.read(MAX_UPLOAD_BYTES + 1)

        if len(content) > MAX_UPLOAD_BYTES:
            raise HTTPException(
                status_code=413,
                detail="Maximum upload size is 10 MB.",
            )

        if not content:
            raise HTTPException(
                status_code=400,
                detail="The uploaded file is empty.",
            )

        # 4. Decode the SQL source.
        try:
            source = content.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise HTTPException(
                status_code=400,
                detail="The file must use UTF-8 encoding.",
            ) from exc

        # 5. Parse the SQL.
        # These argument names match app/sql_parser.py.
        try:
            parser_result = parse_sql_text(
                sql_text=source,
                source_file=filename,
                dialect=dialect,
                include_raw_sql=include_raw_sql,
            )
        except ValueError as exc:
            raise HTTPException(
                status_code=400,
                detail=str(exc),
            ) from exc

        # 6. Build the intermediate representation.
        ir = build_ir_from_parser_result(
            source=source,
            filename=filename,
            dialect=dialect,
            parser_result=parser_result,
        )

        # 7. Validate the IR.
        validation = validate_ir(ir)

        # 8. Add upload metadata.
        ir["source_bytes"] = len(content)
        ir["upload_sha256"] = hashlib.sha256(content).hexdigest()
        ir["ir_validation"] = validation

        # 9. Apply the raw SQL preference.
        if not include_raw_sql:
            for statement in ir["statements"]:
                statement.pop("raw_sql", None)

        logger.info(
            "Parsed %s as %s: %s statements, %s failures, IR valid=%s",
            filename,
            dialect,
            ir["statement_count"],
            ir["failed_count"],
            validation["valid"],
        )

        return ir

    finally:
        await file.close()



