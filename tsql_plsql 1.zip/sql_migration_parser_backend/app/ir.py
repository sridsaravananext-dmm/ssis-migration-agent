
from __future__ import annotations

from typing import Any
from pathlib import Path
import hashlib


SCHEMA_VERSION = "1.2"


def calculate_sha256(content: str) -> str:
    """Return the SHA-256 hash of the source SQL."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def create_statement_ir(
    statement_id: int,
    raw_sql: str,
    dialect: str,
    start_line: int = 1,
    end_line: int = 1,
    statement_type: str = "UNKNOWN",
    parsed: bool = False,
    tables: list[str] | None = None,
    source_tables: list[str] | None = None,
    target_tables: list[str] | None = None,
    columns: list[str] | None = None,
    aliases: dict[str, str] | None = None,
    procedure: dict[str, Any] | None = None,
    assignment: dict[str, Any] | None = None,
    dynamic_sql: dict[str, Any] | None = None,
    diagnostics: list[str] | None = None,
) -> dict[str, Any]:
    """Build a consistent IR record for one SQL statement."""

    return {
        "statement_id": statement_id,
        "statement_type": statement_type,
        "dialect": dialect,
        "start_line": start_line,
        "end_line": end_line,
        "parsed": parsed,
        "raw_sql": raw_sql.strip(),
        "tables": list(tables or []),
        "source_tables": list(source_tables or []),
        "target_tables": list(target_tables or []),
        "columns": list(columns or []),
        "aliases": dict(aliases or {}),
        "procedure": procedure,
        "assignment": assignment,
        "dynamic_sql": dynamic_sql,
        "diagnostics": list(diagnostics or []),
    }


def create_ir(
    source_text: str,
    source_file: str,
    dialect: str,
    statements: list[dict[str, Any]],
    failed_count: int = 0,
) -> dict[str, Any]:
    """
    Build the document-level Intermediate Representation.

    `statements` should contain the statement IR records produced by
    create_statement_ir().
    """

    normalized_dialect = dialect.strip().lower()

    if normalized_dialect not in {"tsql", "plsql"}:
        raise ValueError(
            "Unsupported dialect. Choose 'tsql' or 'plsql'."
        )

    statement_count = len(statements)
    parsed_count = sum(
        1 for statement in statements if statement.get("parsed", False)
    )

    actual_failed_count = statement_count - parsed_count

    return {
        "schema_version": SCHEMA_VERSION,
        "source_file": Path(source_file).name,
        "source_sha256": calculate_sha256(source_text),
        "dialect": normalized_dialect,
        "statement_count": statement_count,
        "parsed_count": parsed_count,
        "failed_count": actual_failed_count,
        "status": (
            "success"
            if actual_failed_count == 0
            else "partial_success"
            if parsed_count > 0
            else "failed"
        ),
        "statements": statements,
    }
